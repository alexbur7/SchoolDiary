package com.example.schooldiary.model;

public enum Subjects{
    Science,
    Literature,
    Another
}
