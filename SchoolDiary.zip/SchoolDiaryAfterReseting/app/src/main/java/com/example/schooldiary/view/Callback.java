package com.example.schooldiary.view;

import androidx.fragment.app.Fragment;

public interface Callback {
    void replaceFragmentWithBackStack(Fragment fragment);
}
